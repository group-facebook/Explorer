Request URL: https://www.juggle-jack.com/store/bliblico
Request method: POST
content-type: application/x-www-form-urlencoded
Expect: 
User-Agent: GitHub-Hookshot/a0a6977
X-GitHub-Delivery: 71bf8000-4b3b-11e9-9b70-213eecd736e0
X-GitHub-Event: ping
X-Hub-Signature: sha1=88e40f07fe7dae56e430f6ca98b5ed1196ded389

